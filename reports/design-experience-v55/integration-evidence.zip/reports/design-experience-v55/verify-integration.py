from pathlib import Path
import hashlib
import json
import re
import subprocess

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
SLUG = 'engos-design-experience'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def write_json(path, obj):
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + '\n')

candidate = (OUT / 'candidate' / f'{SLUG}.md').read_bytes()
canonical = (ROOT / f'ssot/{SLUG}.md').read_bytes()
assert canonical == candidate, 'Canonical entry differs from reviewed candidate'
author = json.loads((OUT / 'author-receipt.json').read_text())
source_hashes = author['candidate_files_sha256']
for rel, expected in source_hashes.items():
    assert sha((OUT / 'frozen-source' / rel).read_bytes()) == expected, rel
    if rel.startswith('resources/'):
        assert sha((ROOT / 'sources/capability-resources' / SLUG / rel.removeprefix('resources/')).read_bytes()) == expected, rel

body = canonical.decode().split('---', 2)[2].strip()
surfaces = {}
for cli in ['codex', 'gemini', 'claude', 'kiro', 'grok']:
    skill = ROOT / f'.{cli}/skills/{SLUG}'
    entry = (skill / 'SKILL.md').read_text()
    emitted_body = entry.split('---', 2)[2].strip()
    assert emitted_body.removesuffix('Capability resource: `resources/capability.json`').rstrip() == body, cli
    assert (skill / 'resources/capability.json').read_bytes() == (ROOT / f'.meta/capabilities/{SLUG}.json').read_bytes(), cli
    for rel, expected in source_hashes.items():
        if rel.startswith('resources/'):
            assert sha((skill / rel).read_bytes()) == expected, f'{cli}/{rel}'
    links = []
    for path in sorted(skill.rglob('*.md')):
        for target in re.findall(r'\]\(([^)]+)\)', path.read_text()):
            if '://' in target or target.startswith('#'):
                continue
            resolved = (path.parent / target.split('#', 1)[0]).resolve()
            assert resolved.exists(), f'{path}: {target}'
            links.append({'source': str(path.relative_to(skill)), 'target': target})
    surfaces[cli] = {'entry_sha256': sha((skill / 'SKILL.md').read_bytes()), 'descriptor_sha256': sha((skill / 'resources/capability.json').read_bytes()), 'authored_resources_equal': 9, 'local_links_resolve': len(links)}

unchanged = {}
for slug in ['loopy', 'engos-design-plan-to-goal']:
    paths = subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', 'HEAD', f'ssot/{slug}.md', f'sources/capability-resources/{slug}', f'sources/skill-package-resources/{slug}', f'sources/intake/{slug}'], cwd=ROOT, text=True).splitlines()
    for path in paths:
        committed = subprocess.check_output(['git', 'show', f'HEAD:{path}'], cwd=ROOT)
        assert (ROOT / path).read_bytes() == committed, path
    old = json.loads(subprocess.check_output(['git', 'show', f'HEAD:.meta/capabilities/{slug}.json'], cwd=ROOT))
    new = json.loads((ROOT / f'.meta/capabilities/{slug}.json').read_text())
    changed = sorted(key for key in set(old) | set(new) if old.get(key) != new.get(key))
    assert changed == ['consumption_hints', 'job_contract'], (slug, changed)
    assert old['consumption_hints']['requires_human_confirmation'] == new['consumption_hints']['requires_human_confirmation']
    unchanged[slug] = {'operating_files_equal_to_main': len(paths), 'ssot_sha256': sha((ROOT / f'ssot/{slug}.md').read_bytes()), 'descriptor_changed_fields': changed, 'confirmation_policy_preserved': True}
    if slug == 'loopy':
        provenance = json.loads((ROOT / 'sources/intake/loopy/provenance.json').read_text())
        for rel, bound in provenance['files'].items():
            assert sha((ROOT / 'sources/intake/loopy/package' / rel).read_bytes()) == bound['sha256'], rel
        unchanged[slug]['pinned_intake_hashes_match_provenance'] = True

assert not (ROOT / f'sources/ssot-baselines/{SLUG}').exists(), 'Unexpected behavioral baseline'
apply = json.loads((OUT / 'uac-apply.json').read_text())
assert apply['status'] == 'applied'
assert apply['apply_result']['behavioral_evidence']['status'] == 'behavioral_pending'
assert apply['quality_result']['final_candidate_text'].encode() == canonical
descriptor = json.loads((ROOT / f'.meta/capabilities/{SLUG}.json').read_text())
assert descriptor['quality_status'] == 'structural_ready'
assert descriptor['historical_baseline']['baseline_path'] is None

baseline = (OUT / 'baseline-v5-canonical.md').read_text()
def sections(text):
    lines = text.splitlines()
    starts = [0] + [i for i, line in enumerate(lines) if line.startswith('## ')]
    return [(start + 1, starts[i + 1] if i + 1 < len(starts) else len(lines), '\n'.join(lines[start:starts[i + 1] if i + 1 < len(starts) else len(lines)]).rstrip()) for i, start in enumerate(starts)]

mapping = []
for i, (old, new) in enumerate(zip(sections(baseline), sections(canonical.decode())), 1):
    start, end, text = old
    mapping.append({'id': f'v5-section-{i}', 'source_start_line': start, 'source_end_line': end, 'candidate_start_line': new[0], 'candidate_end_line': new[1], 'disposition': 'preserved' if text == new[2] else 'reformulated', 'review_rationale': 'See the independently authored section-by-section and resource review in preservation-review.md; these line ranges bind that review to the frozen texts.'})
write_json(OUT / 'preservation-map.json', {'schema_version': 'DevelopmentRequirementPreservation.v1', 'reviewer': '/root/v55_release_readiness', 'author': '/root/v55_candidate', 'baseline_sha256': sha(baseline.encode()), 'candidate_sha256': sha(canonical), 'behavioral_claim': 'none', 'submitted_as_promotion_or_historical_baseline': False, 'requirements': mapping})
receipt = {'status': 'structural_readback_passed', 'canonical_sha256': sha(canonical), 'author_manifest_sha256': author['candidate_manifest_sha256'], 'author_entry_sha256': source_hashes['SKILL.md'], 'authored_resource_count': 9, 'surfaces': surfaces, 'unchanged_sources': unchanged, 'uac_status': 'applied', 'quality_status': 'structural_ready', 'behavioral_status': 'behavioral_pending', 'behavioral_baseline_materialized': False, 'evidence_limit': 'Source/resource preservation, metadata boundaries, generated parity and local structural checks. Not model efficacy, human validation, installed acceptance or formal promotion.'}
write_json(OUT / 'integration-readback.json', receipt)
print(json.dumps(receipt, indent=2))
