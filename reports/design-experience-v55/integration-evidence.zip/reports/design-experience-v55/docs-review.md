# Documentation review: Experience Design

## Current State

Reviewed from verified main commit `4401f7fc13d151314ed64d03f88a52f107fe33e7` in the isolated release worktree. The work began with current main documentation, retaining the recent installation/discovery work. Scope was README, active non-generated documentation, their existing public-doc contract test, and this receipt. Canonical capability integration, generated views, changelog, version, and release work have separate owners.

The active docs now introduce Experience Design through an actual task, show the invocation forms by host, and provide report, web, native, small-change, and selectable state-failure examples. README shrank from 393 to 64 lines; Getting Started from 237 to 69. Rich existing capability examples remain in their canonical examples page.

## What Belongs Where

| Concept | Canonical home | Entry links |
| --- | --- | --- |
| Product orientation and first task | `README.md` | docs home and getting started |
| Host invocation and first successful use | `docs/GETTING-STARTED.md` | README and docs home |
| Concrete capability asks, response shape, and design failure probes | `docs/EXAMPLES.md` | README, getting started, CLI reference, docs home |
| Reviewed installation, ownership, discovery, recovery | `docs/INSTALL-PROFILES.md` | quickstart and onboarding |
| Exact commands and write effects | `docs/CLI-REFERENCE.md` | onboarding and technical hub |
| Release lifecycle, profile/legacy distinctions, and release watch | `docs/RELEASE-PACKAGING.md` | CLI, onboarding, maintainer guide |
| Structural intake and advisory apply | `docs/UAC-USAGE.md` | onboarding and maintainer guide |
| Behavioral promotion | `docs/CAPABILITY-EVALUATION.md` | UAC and onboarding |
| Policy | `AGENTS.md` and `.kiro/steering/` | maintainer guide; no new policy invented in docs |
| Historical authoring material | existing architecture assessment and prompt-pack paths | explicitly identified as historical; original prompt bodies retained |

## Drift Findings

| Finding | Resolution | Source checked |
| --- | --- | --- |
| README duplicated full indexes, agent tables, transcripts, and maintainer detail; some links embedded one machine's absolute path | Replaced with concise tasks and portable links to canonical homes | existing examples, catalog, docs steering |
| Examples claimed every skill but omitted Feature Status | Added a scope-first, evidence-qualified feature readiness example | `ssot/engos-audit-feature-status.md` |
| Grok absent from architecture, provider, technical, and CLI surface descriptions | Added Grok skill paths and stated no native Grok agent surface | `.meta/surface-rules.json`, generated path conventions |
| Agent eligibility described as older `kind`/`role` metadata | Documented `capability_type: agent/both` and the artifact matrix | builder and surface rules |
| CLI table marked generation and evidence-writing checks as nonmutating | Replaced binary mutation column with specific write effects | wrapper help, scripts and report paths |
| Smoke docs advertised disabled Claude discovery and omitted Grok | Matched the current configured discovery set | `.meta/surface-rules.json` tooling entries |
| UAC example invented structural `hold`, used an unprefixed slug, and implied proof must precede advisory structural apply | Replaced with actual structural/evaluation fields, canonical slug, and explicit advisory policy | `scripts/uac-import.py`, UAC help, evaluation policy |
| CLI release description conflated saved-profile and legacy acceptance/recovery | Linked the canonical lifecycle and summarized each real path | updater help, profile guide, release guide |
| Release comparison instructions hardcoded an old release pair | Required an explicitly set, verified previous tag before build | build baseline support and current release workflow |
| Tests enforced lifecycle paragraphs in every onboarding page | Retained contract assertions at CLI/release homes and checked onboarding links; added existing profile/legacy recovery distinctions | `tests/test_public_docs_contract.py` |

## Recommended Changes

The targeted changes above are applied. Generated catalog, job-map, manifest, and surface checks were coordinated with their integration owner and reviewed after generation. No generated documentation was hand-edited by this reviewer.

## Examples of Good Output

The Experience Design examples make the requested output concrete: a rendered report with qualified evidence; an editor whose displayed status agrees with the API; a native change with target-runtime gaps identified; and a small revision that preserves the selected direction. Optional probes distinguish failed persistence, a committed operation whose reply is lost, and draft changes during an unresolved operation. They select relevant checks without prescribing a fixed workflow, layout, reviewer count, or fake backend semantics.

## Verification

- Read all active top-level docs and inspected the nested assets/prompt-pack indexes; audited local links across all 32 README/docs Markdown files.
- Initial local link/anchor check: 170 links, zero missing paths or anchors. This check excludes external URL availability and code examples.
- Verified help for `bin/capability-fabric`, its deploy/update commands, `bin/uac` and judge, `scripts/deploy-profile.py`, `scripts/smoke-clis.py`, `bin/capability-eval compare`, and `scripts/package-surfaces.sh`.
- Final focused suite after generation: `python3 -m pytest -q tests/test_public_docs_contract.py tests/test_batman_companion_portability.py tests/test_capability_recovery.py`: 40 passed.
- Generated readback: 28 skills on each of the five CLI surfaces and 11 agents on each agent-capable surface. Experience Design is skill-only; README count and CLI guidance were aligned to that emitted reality. Catalog and job-map entries match the canonical design purpose and the curated Loopy/Plan-to-Goal boundaries.
- Every canonical skill has a dedicated installed-skill example. Final local docs link/anchor and whitespace checks passed.
- Independent candidate-author review read the four user-facing design pages. It found and resolved a mobile-web/native simulation ambiguity, two overstrong outcome phrases, and a missing assessment/options-only fidelity example; no remaining material documentation findings.
- `git diff --check` passed.
- Official invocation guidance checked on 2026-09-09: [Claude skills](https://code.claude.com/docs/en/skills), [Gemini skills](https://geminicli.com/docs/cli/skills/), and [Kiro skills](https://kiro.dev/docs/skills/). The old Kiro CLI skills URL redirects to the current feature page. These source checks establish documented forms, not authenticated runtime acceptance.

## Review Timing

Review the canonical and generated capability names, inventory counts, and links after integration; recheck adjacent docs before merge and compare packaged docs with the release source before publishing. Hosted checks, installed parity, and live acceptance remain their own evidence.

## Open Risks

The final generated index and focused count check passed. Full release validation, hosted checks, and publication remain with their delivery owners. External design resource catalogs retain dated provenance and per-reference limits; this docs pass does not assert new component, license, accessibility, or native-runtime audits. Behavioral status may remain `behavioral_pending` under the advisory rollout; neither these docs nor an agent review authorizes formal promotion.
