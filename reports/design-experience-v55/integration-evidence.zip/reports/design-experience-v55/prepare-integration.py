from pathlib import Path
import hashlib
import json
import difflib

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
SOURCE = Path('/private/tmp/experience-design-v55-01a07fad/candidate')
BASELINE = Path('/private/tmp/experience-design-v5-01a07fad/frozen/v5')
V5 = Path('/private/tmp/core-prompts-design-experience-v5-01a07fad')
SLUG = 'engos-design-experience'

def digest(data):
    return hashlib.sha256(data).hexdigest()

def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data if isinstance(data, bytes) else data.encode())

def json_write(path, obj):
    write(path, json.dumps(obj, indent=2, ensure_ascii=False) + '\n')

def inventory(path):
    return {str(p.relative_to(path)): digest(p.read_bytes()) for p in sorted(path.rglob('*')) if p.is_file()}

receipt = json.loads((SOURCE.parent / 'author-receipt.json').read_text())
current = inventory(SOURCE)
assert current == receipt['candidate_files_sha256'], 'Author receipt no longer matches candidate'
assert inventory(BASELINE) == receipt['baseline_files_sha256'], 'V5 baseline changed'
for rel in current:
    write(OUT / 'frozen-source' / rel, (SOURCE / rel).read_bytes())
for rel in inventory(BASELINE):
    write(OUT / 'baseline-v5-package' / rel, (BASELINE / rel).read_bytes())
write(OUT / 'author-receipt.json', (SOURCE.parent / 'author-receipt.json').read_bytes())

source = (SOURCE / 'SKILL.md').read_text()
_, header, body = source.split('---', 2)
canonical = '---' + header + 'display_name: "Experience Design"\nkind: "skill"\ncapability_type: "skill"\n---' + body
canonical = canonical.rstrip() + '\n'
write(OUT / 'candidate' / f'{SLUG}.md', canonical)
baseline = (V5 / f'ssot/{SLUG}.md').read_text()
write(OUT / 'baseline-v5-canonical.md', baseline)
for rel in current:
    if rel.startswith('resources/'):
        write(ROOT / 'sources/capability-resources' / SLUG / rel.removeprefix('resources/'), (SOURCE / rel).read_bytes())

def sections(text):
    lines = text.splitlines()
    starts = [0] + [i for i, line in enumerate(lines) if line.startswith('## ')]
    return [(start + 1, starts[i + 1] if i + 1 < len(starts) else len(lines), '\n'.join(lines[start:starts[i + 1] if i + 1 < len(starts) else len(lines)]).rstrip()) for i, start in enumerate(starts)]

requirements = []
for i, (start, end, excerpt) in enumerate(sections(canonical), 1):
    requirements.append({'id': f'intake-section-{i}', 'source_start_line': start, 'source_end_line': end, 'disposition': 'preserved', 'candidate_excerpt': excerpt, 'rationale': 'Independent reviewer read this complete normalized intake section and the linked resources. Canonical application retains its exact content. V5-to-V5.5 meaning changes are reviewed separately in preservation-review.md and resource-review.json; this binding does not claim behavioral efficacy.'})
review = {'schema_version': 'UACRequirementReview.v1', 'slug': SLUG, 'original_sha256': digest(canonical.encode()), 'candidate_sha256': digest(canonical.encode()), 'effective_sha256': digest(canonical.encode()), 'verdict': 'approved', 'reviewer': {'agent_id': '/root/v55_release_readiness', 'author_agent_id': '/root/v55_candidate', 'controller_agent_id': '/root', 'independent': True}, 'provenance': 'Actual independent full-source and resource review by /root/v55_release_readiness, delegated separately from author /root/v55_candidate. Canonical frontmatter and terminal newline were normalized before binding. This new-skill intake preserves the exact submitted canonical candidate. V5 is an unpromoted development lineage, not a repository behavioral baseline. Legacy direct-link resources are independently hash-bound in resource-review.json; effective_sha256 is entry-only and makes no assembled-resource or consumption claim.', 'requirements': requirements}
json_write(OUT / 'requirement-review-intake.json', review)

resource_review = {'reviewer': '/root/v55_release_readiness', 'author': '/root/v55_candidate', 'source_files_sha256': current, 'baseline_files_sha256': inventory(BASELINE), 'canonical_sha256': digest(canonical.encode()), 'changes': {}}
rationales = {
    'resources/references/whole-experience-contract.md': 'Preserves identity, ownership, decision context, continuation, foundation, meaningful detail access and dependency tracing. Adds task-state access at commitment/replacement/retry and explicitly avoids universal sticky/simultaneous/above-fold layout requirements.',
    'resources/references/compare-edit-compare.md': 'Preserves task/composition comparison, optional independent review, bounded evidence, reversions, stopping, actual-platform limits and dependency-based check renewal. Refines inspection to the state after the last edit and supplies captured working-state evidence to optional reviewers.',
    'resources/references/platform-and-resource-selection.md': 'Editorial provenance cleanup only. Retains the inspection date, every source link and availability limit, the explicit lack of current reinspection, platform adaptability, reuse checks and fallback boundaries.',
    'resources/examples/worked-decisions.md': 'Removes only the development-version label from the unresolved hypothesis sentence. Preserves the whole diagnostic narrative and all experimental, human-outcome, visual, interaction and runtime limitations.',
    'resources/references/state-failure-probes.md': 'New optional resource for failed persistence/reload, reply lost after commitment, and retry/edit transitions while unresolved. Probes are conditional, compare visible claims to actual state authority, require scoped test access, preserve uncertainty and do not invent service behavior, fixed layouts, workflows or backend authority.'}
for rel in current:
    if rel == 'SKILL.md':
        continue
    old = BASELINE / rel
    unchanged = old.is_file() and old.read_bytes() == (SOURCE / rel).read_bytes()
    resource_review['changes'][rel] = {'disposition': 'preserved' if unchanged else 'reformulated' if old.is_file() else 'added', 'rationale': 'Full text read and exact bytes retained.' if unchanged and rel.endswith('.md') else 'Exact image bytes retained; not new runtime or human evidence.' if unchanged else rationales[rel]}
json_write(OUT / 'resource-review.json', resource_review)
write(OUT / 'baseline-to-candidate.diff', ''.join(difflib.unified_diff(baseline.splitlines(True), canonical.splitlines(True), fromfile='V5 canonical development draft', tofile='V5.5 normalized intake')))
print(json.dumps({'candidate_sha256': digest(canonical.encode()), 'authored_source_sha256': digest(source.encode()), 'resources': len(current) - 1, 'review': str(OUT / 'requirement-review-intake.json')}, indent=2))
