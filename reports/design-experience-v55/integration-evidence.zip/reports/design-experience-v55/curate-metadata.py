from pathlib import Path
import json
import hashlib

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
V5 = Path('/private/tmp/core-prompts-design-experience-v5-01a07fad')
SLUG = 'engos-design-experience'

def load(path):
    return json.loads(path.read_text())

def save(path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n')

job_path = ROOT / '.meta/skill-job-map.json'
jobs = load(job_path)
before = {'job_map': {slug: jobs['skills'].get(slug) for slug in ['loopy', 'engos-design-plan-to-goal', SLUG]}, 'descriptors': {}}
design = load(V5 / f'.meta/capabilities/{SLUG}.json')
jobs['skills'][SLUG] = design['job_contract']
jobs['skills']['loopy'] = {
    'primary_job': 'Discover, find, design, audit, run, or improve a bounded agent loop from scoped evidence.',
    'use_when': 'Repeated work needs a feedback loop, an existing loop needs review, or an identified loop needs execution, debriefing, or publication preparation.',
    'works_on': 'Scoped repositories and coding threads, loop prompts, the live Loop Library catalog, and completed run receipts.',
    'main_output': 'Published-loop recommendations, a concise bounded loop, a loop audit or repair, an evidence-backed run receipt, a debrief, or an approved publication submission for the selected route.',
    'not_for': 'One-shot work with no useful feedback cycle, a host-specific goal packet, or claiming publication from repository content alone.',
    'authority': 'Selecting or crafting does not run a loop. A run permits only ordinary reversible actions in scope; schedules, production changes, destructive or privacy-sensitive actions, purchases, external messages, and publication require their explicit authority.',
    'routing_question': 'Is the need to discover or operate a repeatable feedback loop, or to compile one implementation plan into a host-bound goal packet?',
    'nearest_neighbors': ['engos-design-plan-to-goal', 'engos-optimization-auto-research'],
    'shape': 'workflow_infrastructure',
    'portfolio_action': 'keep_and_clarify_boundary',
}
jobs['skills']['engos-design-plan-to-goal'] = {
    'primary_job': 'Compile a reviewed plan into a durable, host-aware goal, specification, and verifier packet.',
    'use_when': 'An implementation intent needs bounded long-running execution with repository evidence, honest completion criteria, and a verified host contract.',
    'works_on': 'A plan or intent, the target repository and rules, the active host, user-supplied bounds, protected surfaces, and acceptance evidence.',
    'main_output': 'Goal prose, specification, verifier and packet manifest, with research, trust, sealing status, host budget, and a supported launch command when ready.',
    'not_for': 'Ordinary one-step implementation, a repeatable loop catalog search, inventing a native runner, or executing the compiled goal without a separate request.',
    'authority': 'Compiles and validates the packet within current permissions. It does not implicitly create or operate a goal, implement source changes, approve operator checks, promote behavior, deploy, commit, or merge.',
    'routing_question': 'Does an existing plan need a durable goal/specification/verifier packet bound to a verified host?',
    'nearest_neighbors': ['loopy', 'engos-memory-context-continuity', 'engos-design-architecture'],
    'shape': 'workflow_infrastructure',
    'portfolio_action': 'keep_and_clarify_boundary',
}
save(job_path, jobs)

for slug in ['loopy', 'engos-design-plan-to-goal', SLUG]:
    path = ROOT / f'.meta/capabilities/{slug}.json'
    descriptor = load(path)
    before['descriptors'][slug] = descriptor
    if slug == SLUG:
        for key in ['consumption_hints', 'shared_constraints', 'quality_validation_matrix']:
            descriptor[key] = design[key]
        descriptor['layers']['expanded']['adjustment_recommendations'] = []
        descriptor['layers']['expanded']['capability_dependencies'] = []
        descriptor['layers']['expanded']['migration_notes'] = [
            'New direct skill for UI experience decisions; existing Architecture retains backend and system design, and Plan to Goal retains goal-packet compilation.',
            'Generated surfaces are structural delivery evidence. Formal behavioral status remains pending; no promoted baseline is introduced.',
        ]
    elif slug == 'loopy':
        descriptor['consumption_hints'].update({
            'preferred_use_cases': ['discover repeated engineering work and find a published loop', 'craft, adapt, audit, or repair a bounded loop', 'run an identified loop, debrief its receipt, or prepare publication with the required approval'],
            'artifact_conventions': [],
            'invocation_style': 'interactive_mode_selection',
        })
    else:
        descriptor['consumption_hints'].update({
            'preferred_use_cases': ['compile an implementation plan into a host-aware goal packet', 'research and verify goal, specification, and verifier trust', 'seal a durable packet and report its supported launch command'],
            'artifact_conventions': ['goal.txt', 'spec.md', 'verify.sh', 'packet.json', 'baseline.json', 'criterion-flips.json', 'judge-amendments.json'],
            'invocation_style': 'assistant_first_packet_compilation',
        })
    descriptor['job_contract'] = jobs['skills'][slug]
    save(path, descriptor)
save(OUT / 'metadata-before-curation.json', before)
source_hashes = {slug: hashlib.sha256((ROOT / f'ssot/{slug}.md').read_bytes()).hexdigest() for slug in ['loopy', 'engos-design-plan-to-goal']}
save(OUT / 'unchanged-source-hashes.json', source_hashes)
print(json.dumps({'curated_slugs': ['loopy', 'engos-design-plan-to-goal', SLUG], 'unchanged_operating_sources': source_hashes}, indent=2))
