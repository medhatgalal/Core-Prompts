# V5.5 canonical integration evidence

Base: `4401f7fc13d151314ed64d03f88a52f107fe33e7` on isolated branch `AI/design-experience-v55-release`. Integration owner and independent preservation reviewer: `/root/v55_release_readiness`; source author: `/root/v55_candidate`.

## Result

Fresh UAC plan and judge accepted the exact normalized candidate in one pass. The first apply wrote the candidate and failed only because seven ignored schema-cache entries were absent in the fresh worktree. That receipt is preserved as `uac-apply-initial.json`. After official-source cache refresh, the repeated exact apply returned `applied`, with strict validation passing for all 28 SSOT entries. Its evidence remains `structural_ready` / `behavioral_pending`; no promoted baseline was created.

| Identity | SHA-256 |
| --- | --- |
| Final authored package inventory | `b0234cf7689e607d42825b77cc587dcbf21550252ecbd6fa8d5c0ed49ec7e867` |
| Authored SKILL.md | `c0716e9e52258930f45b9dbd733f80d9f358183b11aa186e18e1509585c2c922` |
| Normalized canonical SSOT | `73ff64165b26672ee1be3af086b79f88f7bbea5a5f4b14352af35a477a9202ca` |
| Each generated SKILL.md | `ff21661ff1678e7ad4d54e5db8a7685d43004bf58b4805083caef49307e65b9b` |
| Canonical and each bundled descriptor | `fbbc4c097fbd9bfcf1bb9cffa1554b5065b7e4560fc06bd02408bf0b52e2b10b` |

Only canonical frontmatter and terminal-newline normalization distinguish authored and canonical entry forms. All nine authored resources match the frozen source on all five surfaces. All 12 local links resolve on every surface. The generated footer and descriptor are regenerated outputs.

## Focused checks

- `python3 -m pytest -q tests/test_uac_source_integrity.py tests/test_resource_source_integrity.py tests/test_skill_package_resources.py tests/test_capability_resources.py tests/test_resource_delivery.py tests/test_skill_job_map.py tests/test_uac_promotion_apply.py`: **135 passed**.
- `bin/capability-eval compile --all --check`: **pass**, 28 skills, no generated drift.
- `bin/capability-eval calibrate --static-only`: **structural_ready**, 14 controls, no missing controls or corpus blockers, 60 public cases across four pilot foundations, zero model calls. Semantic judges remain unqualified.
- `bin/capability-fabric validate --strict`: **passed**, 28 SSOT entries.
- `python3 reports/design-experience-v55/verify-integration.py`: **structural_readback_passed**.
- `git diff --check`: **passed**.

The docs owner separately reports **40 passed** focused public-doc, continuity and Batman tests, including final generated counts: 28 skills and 11 agents on each agent-capable host. See `docs-review.md` for their evidence and ownership.

## Preservation and metadata

`preservation-review.md`, `preservation-map.json` and `resource-review.json` document the actual independent review of the full V5/V5.5 entry and resources. The UAC requirement attestation binds the actual normalized intake; its legacy effective-text hash covers the entry only. Resource hashes and review are separate and do not claim machine-assembled consumption.

Legitimate V5 design metadata was retained selectively: consumption hints, shared constraints, curated validation matrix and job contract. Historical V5 judge results and development baselines were not represented as current promotion evidence. New UAC receipts own the current quality result.

Loopy and Plan to Goal changed only `consumption_hints` and `job_contract` descriptor fields, plus their canonical job-map rows and generated metadata/docs. Their confirmation booleans, tool/authority policies, quality reports, historical lineage and operating sources remain unchanged. Readback verifies 19 Loopy source/intake/companion files and 17 Plan-to-Goal files against main; all pinned Loopy intake hashes still match its unchanged provenance record.

## Remaining lifecycle

No commit, push, PR/MR, merge, package, tag, release, home installation or model experiment was performed by this integration owner. The controller owns version/changelog finalization, the development experiment, final full release gates, publication and cleanup. Regenerate after any final version or docs edits before freezing the release artifact. No integration blocker remains.
