#!/usr/bin/env bash
set -euo pipefail

usage() {
  cat <<'EOF'
Usage: scripts/deploy-surfaces.sh [--cli gemini|claude|kiro|codex|all] [--target PATH] [--dry-run] [--strict-cli]

Copy-only deployment of SSOT-managed generated surfaces to CLI directories under a target root.
This script never creates symlinks.
If destination file is a symlink, it is unlinked and replaced with a regular file copy.
Existing files are overwritten in place with cp -f.

Options:
  --cli gemini|claude|kiro|codex|all  Target CLI(s). Default: all
  --target PATH                       Destination root path. Default: ~
  --dry-run                           Show copy actions without writing
  --strict-cli                        Fail when selected CLI binary is not installed
  -h, --help                          Show this help
EOF
}

CLI_TARGET="all"
TARGET_ROOT="$HOME"
DRY_RUN=0
STRICT_CLI=0

while [[ $# -gt 0 ]]; do
  case "$1" in
    --cli)
      shift
      CLI_TARGET="${1:-}"
      ;;
    --target)
      shift
      TARGET_ROOT="${1:-}"
      ;;
    --dry-run)
      DRY_RUN=1
      ;;
    --strict-cli)
      STRICT_CLI=1
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "error: unknown option: $1"
      usage
      exit 1
      ;;
  esac
  shift
done

if [[ -z "$TARGET_ROOT" ]]; then
  echo "error: --target requires a non-empty path"
  usage
  exit 1
fi

TARGET_ROOT="$(python3 - "$TARGET_ROOT" <<'PY'
import os
import sys
print(os.path.abspath(os.path.expanduser(sys.argv[1])))
PY
)"

case "$CLI_TARGET" in
  gemini|claude|kiro|codex|all) ;;
  *)
    echo "error: invalid --cli value: $CLI_TARGET"
    usage
    exit 1
    ;;
esac

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO_ROOT"

if [[ ! -f ".meta/manifest.json" ]]; then
  echo "error: missing .meta/manifest.json"
  echo "Run build first: python3 scripts/build-surfaces.py"
  exit 1
fi

if ! mapfile -t SLUGS < <(python3 - <<'PY'
import json
from pathlib import Path
try:
    manifest = json.loads(Path(".meta/manifest.json").read_text(encoding="utf-8"))
except Exception as exc:
    raise SystemExit(f"manifest_read_error: {exc}")

for entry in manifest.get("ssot_sources", []):
    slug = entry.get("slug")
    if slug:
        print(slug)
PY
); then
  echo "error: unreadable .meta/manifest.json"
  exit 1
fi

if [[ ${#SLUGS[@]} -eq 0 ]]; then
  echo "error: no managed slugs found in .meta/manifest.json"
  exit 1
fi

if ! mapfile -t AGENT_SLUGS < <(python3 - <<'PY'
import json
from pathlib import Path
try:
    manifest = json.loads(Path(".meta/manifest.json").read_text(encoding="utf-8"))
except Exception as exc:
    raise SystemExit(f"manifest_read_error: {exc}")

for entry in manifest.get("ssot_sources", []):
    slug = entry.get("slug")
    kind = (entry.get("kind") or "").strip().lower()
    if slug and kind == "agent":
        print(slug)
PY
); then
  echo "error: unreadable .meta/manifest.json for agent slugs"
  exit 1
fi

is_cli_available() {
  local cli="$1"
  case "$cli" in
    gemini) command -v gemini >/dev/null 2>&1 ;;
    claude) command -v claude >/dev/null 2>&1 ;;
    kiro) command -v kiro-cli >/dev/null 2>&1 ;;
    codex) command -v codex >/dev/null 2>&1 ;;
    *) return 1 ;;
  esac
}

TARGETS=()
if [[ "$CLI_TARGET" == "all" ]]; then
  for candidate in gemini claude kiro codex; do
    if is_cli_available "$candidate"; then
      TARGETS+=("$candidate")
    else
      if [[ "$STRICT_CLI" -eq 1 ]]; then
        echo "error: missing required CLI binary for target '$candidate'"
        exit 1
      fi
      echo "warning: skipping unavailable CLI '$candidate'"
    fi
  done
else
  if ! is_cli_available "$CLI_TARGET"; then
    if [[ "$STRICT_CLI" -eq 1 ]]; then
      echo "error: missing required CLI binary for target '$CLI_TARGET'"
      exit 1
    fi
    echo "warning: selected CLI '$CLI_TARGET' is unavailable; skipping"
  else
    TARGETS+=("$CLI_TARGET")
  fi
fi

if [[ ${#TARGETS[@]} -eq 0 ]]; then
  echo "warning: no target CLIs selected"
  echo "SUMMARY copied=0 missing_source=0 skipped_cli=1"
  exit 0
fi

COPIED=0
MISSING_SOURCE=0
SKIPPED_CLI=0
REPLACED_SYMLINK=0

copy_file() {
  local src="$1"
  local dst="$2"

  if [[ ! -f "$src" ]]; then
    echo "error: missing source file: $src"
    MISSING_SOURCE=$((MISSING_SOURCE + 1))
    return 1
  fi

  if [[ -d "$dst" && ! -L "$dst" ]]; then
    echo "error: destination exists as directory: $dst"
    return 1
  fi

  if [[ "$DRY_RUN" -eq 1 ]]; then
    if [[ -L "$dst" ]]; then
      echo "DRY-RUN REPLACE-SYMLINK $dst"
    fi
    echo "DRY-RUN COPY $src -> $dst"
    return 0
  fi

  mkdir -p "$(dirname "$dst")"
  if [[ -L "$dst" ]]; then
    rm -f "$dst"
    REPLACED_SYMLINK=$((REPLACED_SYMLINK + 1))
    echo "REPLACED SYMLINK $dst"
  fi
  if cp -f "$src" "$dst" 2>/dev/null; then
    echo "COPIED $src -> $dst"
    COPIED=$((COPIED + 1))
  else
    # Non-fatal no-op when source and destination refer to the same file.
    echo "COPIED $src -> $dst (unchanged)"
  fi
  return 0
}

deploy_gemini() {
  local slug="$1"
  copy_file "$REPO_ROOT/.gemini/skills/$slug/SKILL.md" "$TARGET_ROOT/.gemini/skills/$slug/SKILL.md" || return 1
  copy_file "$REPO_ROOT/.gemini/agents/$slug.md" "$TARGET_ROOT/.gemini/agents/$slug.md" || return 1
  copy_file "$REPO_ROOT/.gemini/commands/$slug.toml" "$TARGET_ROOT/.gemini/commands/$slug.toml" || return 1
}

deploy_claude() {
  local slug="$1"
  copy_file "$REPO_ROOT/.claude/agents/$slug.md" "$TARGET_ROOT/.claude/agents/$slug.md" || return 1
  copy_file "$REPO_ROOT/.claude/commands/$slug.md" "$TARGET_ROOT/.claude/commands/$slug.md" || return 1
}

deploy_kiro() {
  local slug="$1"
  copy_file "$REPO_ROOT/.kiro/skills/$slug/SKILL.md" "$TARGET_ROOT/.kiro/skills/$slug/SKILL.md" || return 1
  copy_file "$REPO_ROOT/.kiro/agents/$slug.json" "$TARGET_ROOT/.kiro/agents/$slug.json" || return 1
  copy_file "$REPO_ROOT/.kiro/prompts/$slug.md" "$TARGET_ROOT/.kiro/prompts/$slug.md" || return 1
}

deploy_codex() {
  local slug="$1"
  copy_file "$REPO_ROOT/.codex/skills/$slug/SKILL.md" "$TARGET_ROOT/.codex/skills/$slug/SKILL.md" || return 1
  if [[ " ${AGENT_SLUGS[*]} " == *" $slug "* ]]; then
    copy_file "$REPO_ROOT/.codex/agents/$slug.toml" "$TARGET_ROOT/.codex/agents/$slug.toml" || return 1
  fi
}

register_codex_agents() {
  if [[ ${#AGENT_SLUGS[@]} -eq 0 ]]; then
    return 0
  fi
  local config_path="$TARGET_ROOT/.codex/config.toml"
  if [[ "$DRY_RUN" -eq 1 ]]; then
    echo "DRY-RUN REGISTER codex agents in $config_path: ${AGENT_SLUGS[*]}"
    return 0
  fi
  mkdir -p "$(dirname "$config_path")"
  python3 - "$config_path" "$TARGET_ROOT" "${AGENT_SLUGS[@]}" <<'PY'
from pathlib import Path
import sys

config_path = Path(sys.argv[1]).expanduser()
target_root = Path(sys.argv[2]).expanduser().resolve()
agent_slugs = sorted(set(sys.argv[3:]))

start_marker = "# >>> core-prompts codex agents start >>>"
end_marker = "# <<< core-prompts codex agents end <<<"

if config_path.exists():
    original = config_path.read_text(encoding="utf-8")
else:
    original = ""

lines = []
if original:
    lines = original.splitlines()

start_idx = None
end_idx = None
for idx, line in enumerate(lines):
    if line.strip() == start_marker:
        start_idx = idx
    if line.strip() == end_marker:
        end_idx = idx
        if start_idx is not None:
            break

managed = [start_marker]
for slug in agent_slugs:
    config_file = target_root / ".codex" / "agents" / f"{slug}.toml"
    managed.extend(
        [
            f"[agents.{slug}]",
            f'config_file = "{config_file}"',
            "",
        ]
    )
managed.append(end_marker)
managed_text = "\n".join(managed)

if start_idx is not None and end_idx is not None and end_idx >= start_idx:
    new_lines = lines[:start_idx] + managed_text.splitlines() + lines[end_idx + 1 :]
    updated = "\n".join(new_lines)
else:
    prefix = original.rstrip("\n")
    if prefix:
        updated = prefix + "\n\n" + managed_text + "\n"
    else:
        updated = managed_text + "\n"

config_path.write_text(updated, encoding="utf-8")
PY
  echo "REGISTERED codex agents in $config_path: ${AGENT_SLUGS[*]}"
}

echo "Deploying managed slugs (${#SLUGS[@]}): ${SLUGS[*]}"
echo "Target CLIs: ${TARGETS[*]}"
echo "Target root: $TARGET_ROOT"
if [[ "$DRY_RUN" -eq 1 ]]; then
  echo "Dry-run: enabled"
fi

for cli in "${TARGETS[@]}"; do
  if ! is_cli_available "$cli"; then
    SKIPPED_CLI=$((SKIPPED_CLI + 1))
    echo "warning: skipping unavailable CLI '$cli'"
    continue
  fi

  for slug in "${SLUGS[@]}"; do
    case "$cli" in
      gemini) deploy_gemini "$slug" || exit 1 ;;
      claude) deploy_claude "$slug" || exit 1 ;;
      kiro) deploy_kiro "$slug" || exit 1 ;;
      codex) deploy_codex "$slug" || exit 1 ;;
      *)
        echo "error: unsupported CLI target '$cli'"
        exit 1
        ;;
    esac
  done
done

if [[ " ${TARGETS[*]} " == *" codex "* ]]; then
  register_codex_agents
fi

if [[ "$DRY_RUN" -eq 1 ]]; then
  echo "SUMMARY copied=0 missing_source=$MISSING_SOURCE skipped_cli=$SKIPPED_CLI replaced_symlink=0"
else
  echo "SUMMARY copied=$COPIED missing_source=$MISSING_SOURCE skipped_cli=$SKIPPED_CLI replaced_symlink=$REPLACED_SYMLINK"
fi
